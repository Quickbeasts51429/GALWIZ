require("dotenv").config();
const express = require("express");
const app = express();
const mongoose = require("mongoose");

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
const imageGalleryRouter = require("./routes/main/imageGalleryRouter");
const homeRouter = require("./routes/main/homeRouter");
const adminAuthRouter = require("./routes/admin/adminAuthRouter");
const userAuthRouter = require("./routes/user/userAuthRouter");
const notebookRouter = require("./routes/main/notebookRouter");
const toolNotebookRouter = require("./routes/main/toolNotebookRouter");
const useCaseRouter = require("./routes/main/useCaseRouter");
const discussionRouter = require("./routes/main/discussionRouter");
const workFlowRouter = require("./routes/main/workFlowRouter");
const adminRouter = require("./routes/admin/adminRouter");
const outreachyRouter = require("./routes/main/outreachyRouter");
const DB = process.env.DATABASE;
mongoose
  .connect(DB)
  .then(() => console.log("DB connection successful!"))
  .catch((e) => {
    console.log(`SomeThing went wrong with DataBase. and the error is =  ${e}`);
  });

app.get("/", (req, res) => res.send("<h1>Server is running</h1>"));

// admin routers
app.use("/api/v1/admin", adminAuthRouter);
app.use("/api/v1/admin", adminRouter);

// user routers
app.use("/api/v1/user", userAuthRouter);

// main  routers
app.use("/api/v1/main", outreachyRouter);
app.use("/api/v1/main/image", express.static("public/uploads/useCase/image"));
app.use("/api/v1/main/excel", express.static("public/"));
app.use("/api/v1/user/image", express.static("public/uploads/user/image"));

app.use("/api/v1/main", workFlowRouter);
app.use("/api/v1/main", imageGalleryRouter);

app.use("/api/v1/main", homeRouter);
app.use("/api/v1/user", notebookRouter);
app.use("/api/v1/user", toolNotebookRouter);
app.use("/api/v1/user", useCaseRouter);
app.use("/api/v1/user", discussionRouter);

app.get("*", (req, res) => {
  res.status(500).json({
    status: "success",
    message: "Url not found",
  });
});
app.post("*", (req, res) => {
  res.status(500).json({
    status: "success",
    message: "Url not found",
  });
});

app.delete("*", (req, res) => {
  res.status(500).json({
    status: "success",
    message: "Url not found",
  });
});

app.patch("*", (req, res) => {
  res.status(500).json({
    status: "success",
    message: "Url not found",
  });
});
app.put("*", (req, res) => {
  res.status(500).json({
    status: "success",
    message: "Url not found",
  });
});

const port = process.env.PORT || 8082;

app.listen(port, () => console.log(`Server is running on port ${port}!`));
