import React from "react";

const LogOut = () => {
  return <div>LogOut</div>;
};

export default LogOut;
