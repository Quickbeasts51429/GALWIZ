import React from "react";

const Map = () => {
  return <div>Map</div>;
};

export default Map;
