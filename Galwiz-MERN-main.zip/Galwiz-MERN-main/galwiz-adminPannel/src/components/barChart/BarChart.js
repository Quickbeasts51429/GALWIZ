import React from "react";

const BarChart = () => {
  return <div>BarChart</div>;
};

export default BarChart;
