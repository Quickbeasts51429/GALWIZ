import React from "react";

const IsLoading = () => {
  return <div>IsLoading</div>;
};

export default IsLoading;
